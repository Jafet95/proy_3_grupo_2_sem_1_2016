# proy_3_grupo_2_sem_1_2016
Control y programación RTC con microcontrolador PicoBlaze, incluye manejo de periféricos monitor VGA y teclado USB.
